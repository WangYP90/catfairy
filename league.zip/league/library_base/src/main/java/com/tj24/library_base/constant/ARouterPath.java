package com.tj24.library_base.constant;

/**
 * @Description:
 * @Createdtime:2019/3/3 0:24
 * @Author:TangJiang
 * @Version: V.1.0.0
 */
public class ARouterPath {

}
