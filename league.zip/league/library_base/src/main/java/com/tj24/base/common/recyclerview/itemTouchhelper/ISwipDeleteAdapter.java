package com.tj24.base.common.recyclerview.itemTouchhelper;

/**
 * Created by energy on 2018/1/23.
 */

public interface ISwipDeleteAdapter {
    //数据删除
    void onItemDissmiss(int position);
}
