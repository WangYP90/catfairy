package com.tj24.base.base.app;

/**
 * @Description:application接口
 * @Createdtime:2019/3/3 0:32
 * @Author:TangJiang
 * @Version: V.1.0.0
 */

public interface IApplication {

    void onCreat(BaseApplication application);
}
