package com.tj24.library_base.base.greendao;

import android.content.Context;

import com.tj24.library_base.base.app.BaseApplication;

import org.greenrobot.greendao.AbstractDao;

import java.util.List;

/**
 * @Description:封装greendao基本操作方法
 * @Createdtime:2019/3/2 22:41
 * @Author:TangJiang
 * @Version: V.1.0.0
 */

public abstract class BaseDao<T> {
    private Context mContext;
    private AbstractDao daoHelper;
    public BaseDao() {
        mContext = BaseApplication.getContext();
        daoHelper = getDao();
    }

    public abstract AbstractDao getDao();

    public T queryObjById(Object id){
        if(id==null) return null;
        return (T) daoHelper.load(id);
    }

    public List<T> queryAll(){
      return  daoHelper.loadAll();
    }

    public void insertObj(T t){
        if(t==null) return;
        daoHelper.insertOrReplace(t);
    }

    public void insertList(List<T> ts){
        if(ts==null) return;
        daoHelper.insertOrReplaceInTx(ts);
    }

    public void  deleteObj(T t){
        if(t==null) return;
        daoHelper.delete(t);
    }

    public void deleteList(List<T> ts){
        if(ts==null) return;
        daoHelper.deleteInTx(ts);
    }

    public void deleteById(Object id){
        if(id==null) return;
        daoHelper.deleteByKey(id);
    }

    public void deleteAll(){
        daoHelper.deleteAll();
    }
}
