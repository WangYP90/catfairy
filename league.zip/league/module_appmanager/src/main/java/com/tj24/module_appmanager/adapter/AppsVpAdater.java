package com.tj24.module_appmanager.adapter;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import com.tj24.module_appmanager.bean.AppBean;
import com.tj24.module_appmanager.bean.AppClassfication;
import com.tj24.module_appmanager.fragment.AppsFragment;

import java.util.ArrayList;
import java.util.List;

/**
 * @Description:viewpager的Apdapter
 * @Createdtime:2019/3/17 23:03
 * @Author:TangJiang
 * @Version: V.1.0.0
 */
public class AppsVpAdater extends FragmentPagerAdapter {
    //传入的appbean
    List<AppBean> appBeans = new ArrayList<>();
    //对应的type
    private AppClassfication appClassfication;

    public AppsVpAdater(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int position) {
        return AppsFragment.newInstance(appBeans, appClassfication);
    }

    @Override
    public int getCount() {
        return 5;
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return position+"hello";
    }
}
