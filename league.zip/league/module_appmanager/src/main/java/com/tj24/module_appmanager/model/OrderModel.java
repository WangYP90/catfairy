package com.tj24.module_appmanager.model;

import android.app.Activity;
import com.tj24.library_base.utils.Sputil;
import com.tj24.module_appmanager.common.OrderConfig;

public class OrderModel extends BaseAppsManagerModel {
    public OrderModel(Activity mContext) {
        super(mContext);
    }

    /**
     * 获取排列方式
     * @return
     */
    public int getLayoutType(){
       return Sputil.read(OrderConfig.SP_ORDER,OrderConfig.LAYOUT_LINEAR);
    }

    /**
     * 设置排序方式
     * @param layoutType
     */
    public void  setLayoutType(int layoutType){
        Sputil.save(OrderConfig.SP_ORDER,layoutType);
    }
}
