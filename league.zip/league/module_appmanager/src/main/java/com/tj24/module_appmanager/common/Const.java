package com.tj24.module_appmanager.common;

/**
 * @Description:常量
 * @Createdtime:2019/3/24 14:30
 * @Author:TangJiang
 * @Version: V.1.0.0
 */
public class Const {


}
