package com.tj24.appmanager.activity;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.tj24.appmanager.R;

public class PhotoViewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.app_activity_photo_view);
    }
}
