package com.tj24.appmanager.common;

public class Const {

    public static final String CLASSFICATION_SYSTEM_ID = "e4504a38-fb69-4158-bc28-f07adf91f6b1";
    public static final String CLASSFICATION_SYSTEM_NAME = "系统应用";
    public static final String CLASSFICATION_CUSTOM_ID = "704e9703-26db-4173-a08c-97033fb48a85";
    public static final String CLASSFICATION_CUSTOM_NAME = "我的应用";

}
