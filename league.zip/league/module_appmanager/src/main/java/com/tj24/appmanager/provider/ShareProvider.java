package com.tj24.appmanager.provider;

import androidx.core.content.FileProvider;

public class ShareProvider extends FileProvider {

}
