package com.tj24.module_appmanager.fragment;

import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import butterknife.BindView;
import com.tj24.library_base.base.ui.BaseFragment;
import com.tj24.module_appmanager.R;
import com.tj24.module_appmanager.adapter.RcAppGrideAdapter;
import com.tj24.module_appmanager.adapter.RcAppLinearAdapter;
import com.tj24.module_appmanager.bean.AppBean;
import com.tj24.module_appmanager.bean.AppClassfication;
import com.tj24.module_appmanager.model.BaseAppsManagerModel;
import com.tj24.module_appmanager.view.SideBar;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class AppsFragment extends BaseFragment {
    @BindView(R.id.rc_apps)
    RecyclerView rcApps;
    @BindView(R.id.sideBar)
    SideBar sideBar;
    @BindView(R.id.tv_sidebar)
    TextView tvSidebar;
    @BindView(R.id.tv_move)
    TextView tvMove;
    @BindView(R.id.tv_delete)
    TextView tvDelete;
    @BindView(R.id.tv_info)
    TextView tvInfo;
    @BindView(R.id.tv_levle)
    TextView tvLevle;
    @BindView(R.id.tv_more)
    TextView tvMore;
    @BindView(R.id.ll_footer)
    LinearLayout llFooter;
    //是否正在编辑
    boolean isEditing = false;
    //是否全选 默认为false
    boolean isAllSelected = false;

    //传入的appbean
    private final List<AppBean> appBeans = new ArrayList<>();
    //对应的type
    private AppClassfication appClassfication;
    //长按后 选择的item
    private final List<AppBean> editingApps = new ArrayList<>();

    private RcAppLinearAdapter mLinearAdapter;
    private RcAppGrideAdapter mGrideAdapter;
    private LinearLayoutManager mLinearManager;
    private GridLayoutManager mGrideManager;

    @Override
    public int getCreateViewLayoutId() {
        return R.layout.fragment_apps;
    }

    @Override
    public void init(View view) {
        initRecyclerView();
    }

    /**
     * 初始化recycleView
     */
    private void initRecyclerView() {
        mLinearManager = new LinearLayoutManager(mActivity);

    }

    public static AppsFragment newInstance(List<AppBean> appBeans,AppClassfication appClassfication) {
        AppsFragment f = new AppsFragment();
        Bundle bundle = new Bundle();
        bundle.putSerializable(BaseAppsManagerModel.APP_BEANS, (Serializable) appBeans);
        bundle.putSerializable(BaseAppsManagerModel.APP_CLASSIFICATION, appClassfication);
        f.setArguments(bundle);
        return f;
    }
}
