package com.tj24.module_appmanager.bean;

import org.greenrobot.greendao.annotation.*;

import java.io.Serializable;

/**
 * @Description:app分类
 * @Createdtime:2019/3/21 22:56
 * @Author:TangJiang
 * @Version: V.1.0.0
 */
@Entity
public class AppClassfication implements Serializable {
    private static final long serialVersionUID = 11L;
    @Id@Unique
    /**
     * 类型代码
     */
    private Long typeId;
    /**
     * 对应的排序方式
     */
    private String sortName;
    /**
     * OrderConfig.LAYOUT_LINEAR代表linearlayoutmanager
     * LAYOUT_Gride代表gridelayoutmanager
     */
    private int layoutType;
    /**
     * 类型名称
     */
    private String typeName;
    /**
     * 是否是默认（系统应用，我的应用）
     */
    @Transient
    private boolean isDefault;
    /**
     * 顺序
     */
    private int order;
    @Generated(hash = 713344608)
    public AppClassfication(Long typeId, String sortName, int layoutType,
            String typeName, int order) {
        this.typeId = typeId;
        this.sortName = sortName;
        this.layoutType = layoutType;
        this.typeName = typeName;
        this.order = order;
    }
    @Generated(hash = 1023070321)
    public AppClassfication() {
    }
    public Long getTypeId() {
        return this.typeId;
    }
    public void setTypeId(Long typeId) {
        this.typeId = typeId;
    }
    public String getSortName() {
        return this.sortName;
    }
    public void setSortName(String sortName) {
        this.sortName = sortName;
    }
    public int getLayoutType() {
        return this.layoutType;
    }
    public void setLayoutType(int layoutType) {
        this.layoutType = layoutType;
    }
    public String getTypeName() {
        return this.typeName;
    }
    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }
    public int getOrder() {
        return this.order;
    }
    public void setOrder(int order) {
        this.order = order;
    }

}
