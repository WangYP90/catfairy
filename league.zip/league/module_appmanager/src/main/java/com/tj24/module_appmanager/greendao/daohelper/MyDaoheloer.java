package com.tj24.module_appmanager.greendao.daohelper;

public class MyDaoheloer {
}
