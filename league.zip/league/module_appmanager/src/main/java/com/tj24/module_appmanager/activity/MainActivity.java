package com.tj24.module_appmanager.activity;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.SearchView;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.palette.graphics.Palette;
import androidx.viewpager.widget.ViewPager;
import butterknife.BindView;
import butterknife.OnClick;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.drawable.GlideDrawable;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.tabs.TabLayout;
import com.tj24.library_base.base.ui.BaseActivity;
import com.tj24.library_base.common.UserHelper;
import com.tj24.library_base.utils.ColorUtil;
import com.tj24.library_base.utils.DrawableUtil;
import com.tj24.library_base.utils.ScreenUtil;
import com.tj24.library_base.utils.ToastUtil;
import com.tj24.module_appmanager.R;
import com.tj24.module_appmanager.adapter.AppsVpAdater;
import jp.wasabeef.glide.transformations.BlurTransformation;
import jp.wasabeef.glide.transformations.CropCircleTransformation;

public class MainActivity extends BaseActivity implements NavigationView.OnNavigationItemSelectedListener {
    @BindView(R.id.tab)
    TabLayout tab;
    @BindView(R.id.iv_addItem)
    AppCompatImageView ivAddItem;
    @BindView(R.id.viewpager)
    ViewPager viewpager;
    @BindView(R.id.fbt_compose)
    FloatingActionButton fbtCompose;
    @BindView(R.id.nav_view)
    NavigationView navView;
    @BindView(R.id.drawerLayout)
    DrawerLayout drawerLayout;

    //是否正在编辑
    boolean isEditing = false;
    //已选择数量
    int selectedNum = 0;
    //上次点击back的时间
    double lastClickBackTime = 0;
    //fragmentPageAdapter
    AppsVpAdater vpAdater;

    TextView tvNickName;
    ImageView ivAvatar;
    TextView tvDescription;
    ImageView ivEdit;

    /**
     * glide 加载图片的监听
     */
    RequestListener<Object,GlideDrawable> navHeaderBgLoadListner = new RequestListener<Object, GlideDrawable>() {
        @Override
        public boolean onException(Exception e, Object model, Target<GlideDrawable> target, boolean isFirstResource) {
            return false;
        }

        @Override
        public boolean onResourceReady(GlideDrawable glideDrawable, Object model, Target<GlideDrawable> target, boolean isFromMemoryCache, boolean isFirstResource) {
            if (glideDrawable == null) {
                return false;
            }
            Bitmap bitmap = DrawableUtil.toBitmap(glideDrawable);
            int bitmapWidth = bitmap.getWidth();
            int bitmapHeight = bitmap.getHeight();
            if (bitmapWidth <= 0 || bitmapHeight <= 0) {
                return false;
            }
            int left = (int) (bitmapWidth * 0.2);
            int top = bitmapHeight / 2;
            int bottom = bitmapHeight - 1;
            int right = bitmapWidth - left;
            Palette.from(bitmap)
                    .maximumColorCount(3)
                    .clearFilters()
                    .setRegion(left, top, right, bottom) // 测量图片下半部分的颜色，以确定用户信息的颜色
                    .generate(new Palette.PaletteAsyncListener() {
                        @Override
                        public void onGenerated(@Nullable Palette palette) {
                            boolean isDark = ColorUtil.isBitmapDark(palette, bitmap);
                            int color = isDark?ContextCompat.getColor(MainActivity.this,R.color.white_text):ContextCompat.getColor(mActivity,R.color.colorPrimary);
                            tvNickName.setTextColor(color);
                            tvDescription.setTextColor(color);
                            ivEdit.setColorFilter(color, android.graphics.PorterDuff.Mode.MULTIPLY);
                        }
                    });
            return false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupViews();
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_main;
    }


    public void setupViews() {
        vpAdater = new AppsVpAdater(getSupportFragmentManager());
        tab.setupWithViewPager(viewpager);
        navView.setNavigationItemSelectedListener(this);
        animateToolbar();
        drawerLayout.getViewTreeObserver().addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {
            @Override
            public boolean onPreDraw() {
                navView.getViewTreeObserver().removeOnPreDrawListener(this);
                loadUserInfo();
                return false;
            }
        });
    }

    @Override
    public void setupToolbar() {
        super.setupToolbar();
        toolbar.setTitle(isEditing?"编辑":getString(R.string.app_name));
        toolbar.setNavigationIcon(isEditing?R.drawable.md_nav_back:R.drawable.ico_footer_more);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isEditing){
                    exsitEdit();
                }else {
                    drawerLayout.openDrawer(GravityCompat.START);
                }
            }
        });
    }

    /**
     * 退出编辑回到apps列表
     */
    private void exsitEdit() {

    }
    /**
     * 从apps列表进入到编辑
     */
    private void startEdit() {
    }

    /**
     * 使用缩放动画的方式将Toolbar标题显示出来。
     */
    private void animateToolbar() {
        if(toolbar==null) return;
        View t = toolbar.getChildAt(0);
        if (t != null && t instanceof TextView) {
            t.setAlpha(0f);
            t.setScaleX(0.8f);
            t.animate().alpha(1f)
                    .scaleX(1f)
                    .setStartDelay(300)
                    .setDuration(900);
//                    .setInterpolator(AnimUtils.getFastOutSlowInInterpolator(this));
        }
    }

    @OnClick({R.id.iv_addItem, R.id.fbt_compose})
    public void onViewClicked(View view) {
        switch (view.getId()){
            case R.id.iv_addItem:
                invalidateOptionsMenu();
                isEditing = !isEditing;
                break;
            case R.id.fbt_compose:

                break;
                default:
                    break;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_toobar_apps, menu);
        MenuItem searchItem = menu.findItem(R.id.menu_search);
        final SearchView searchView = (SearchView) searchItem.getActionView();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {

                return false;
            }
        });
        return super.onCreateOptionsMenu(menu);
    }

    /**
     * 动态刷新菜单栏
     * @param menu
     * @return
     */
    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        toolbar.setTitle(isEditing?"编辑":getString(R.string.app_name));
        toolbar.setNavigationIcon(isEditing?R.drawable.md_nav_back:R.drawable.ico_footer_more);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isEditing){
                    exsitEdit();
                }else {
                    drawerLayout.openDrawer(GravityCompat.START);
                }
            }
        });
        menu.findItem(R.id.menu_search).setVisible(!isEditing);
        menu.findItem(R.id.menu_order).setVisible(!isEditing);
        menu.findItem(R.id.menu_refresh).setVisible(!isEditing);
        menu.findItem(R.id.menu_notice).setVisible(!isEditing);
        menu.findItem(R.id.menu_showtype).setVisible(!isEditing);
        MenuItem menuItemSelectedNum = menu.findItem(R.id.menu_selected_num);
        menuItemSelectedNum.setVisible(isEditing);
        menuItemSelectedNum.setTitle("已选择:"+selectedNum);
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                break;
            case R.id.menu_search:
                break;
            case R.id.menu_order:
                break;
            case R.id.menu_refresh:
                break;
            case R.id.menu_showtype:
                break;
            case R.id.menu_notice:
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        if (isEditing) {

        } else {
            if(System.currentTimeMillis() - lastClickBackTime<1500){
                ToastUtil.cancle();
                super.onBackPressed();
            }else {
                showShortToast("再按一次退出应用");
                lastClickBackTime = System.currentTimeMillis();
            }
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        return false;
    }

    /**
     * 加载侧滑栏的用户信息
     */
    private void loadUserInfo() {
        int count = navView.getHeaderCount();
        if (count == 1) {
            String nickname = UserHelper.USER_NICK_NAME;
            String avatar = UserHelper.USER_AVATAR;
            String description = UserHelper.USER_DESCRIPTION;
            String bgImage = UserHelper.USER_BG_IMAG;
            View headerView = navView.getHeaderView(0);
            LinearLayout userLayout = headerView.findViewById(R.id.ll_nav_user);
            LinearLayout descriptionLayout = headerView.findViewById(R.id.ll_nav_describe);
            ImageView ivBgImag = headerView.findViewById(R.id.iv_nav_login_bg);
            ivAvatar = headerView.findViewById(R.id.iv_nav_avatar);
            ivEdit = headerView.findViewById(R.id.iv_nav_edit);
            tvNickName = headerView.findViewById(R.id.tv_nav_nickname);
            tvDescription = headerView.findViewById(R.id.tv_nav_describe);
            tvNickName.setText(nickname);
            if (TextUtils.isEmpty(description)) {
                tvDescription.setText("编辑个人简介");
            } else {
                tvDescription.setText("简介："+description);
            }
            Glide.with(this)
                    .load(avatar)
                    .bitmapTransform(new CropCircleTransformation(this))
                    .placeholder(R.drawable.loading_bg_circle)
                    .error(R.drawable.avatar_default)
                    .diskCacheStrategy(DiskCacheStrategy.SOURCE)
                    .into(ivAvatar);

            if (TextUtils.isEmpty(bgImage)) {
                if (!TextUtils.isEmpty(avatar)) {
                    Glide.with(this)
                            .load(avatar)
                            .bitmapTransform(new BlurTransformation(this, 15))
                            .diskCacheStrategy(DiskCacheStrategy.SOURCE)
                            .listener(navHeaderBgLoadListner)
                            .into(ivBgImag);
                }
            } else {
                int bgImageWidth = navView.getWidth();
                //* 25为补偿系统状态栏高度，不加这个高度值图片顶部会出现状态栏的底色 */)
                float bgImageHeight = ScreenUtil.dip2px(mActivity,250+25);
                Glide.with(this)
                        .load(bgImage)
                        .diskCacheStrategy(DiskCacheStrategy.SOURCE)
                        .override(bgImageWidth, (int) bgImageHeight)
                        .listener(navHeaderBgLoadListner)
                        .into(ivBgImag);
            }
            userLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });
            descriptionLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });
        }
    }
}
