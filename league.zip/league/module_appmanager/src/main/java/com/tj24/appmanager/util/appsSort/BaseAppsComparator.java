package com.tj24.appmanager.util.appsSort;

import com.tj24.base.bean.appmanager.AppBean;

import java.util.Comparator;

/**
 * Created by energy on 2018/1/18.
 */

public abstract class BaseAppsComparator implements Comparator<AppBean> {
}
