package com.tj24.module_appmanager.adapter;

import androidx.annotation.Nullable;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.tj24.module_appmanager.bean.AppBean;

import java.util.List;

/**
 * @Description:app列表的线性adapter
 * @Createdtime:2019/3/24 14:33
 * @Author:TangJiang
 * @Version: V.1.0.0
 */
public class RcAppLinearAdapter extends BaseQuickAdapter<AppBean,BaseViewHolder> {
    public RcAppLinearAdapter(int layoutResId, @Nullable List<AppBean> data) {
        super(layoutResId, data);
    }

    @Override
    protected void convert(BaseViewHolder helper, AppBean item) {

    }
}
