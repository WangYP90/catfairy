package com.tj24.appmanager.model;

import android.app.Activity;

public class AppMainModel extends BaseAppsManagerModel {

    public AppMainModel(Activity mContext) {
        super(mContext);
    }
}
