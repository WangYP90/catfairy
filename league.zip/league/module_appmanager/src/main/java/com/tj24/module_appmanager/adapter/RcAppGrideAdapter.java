package com.tj24.module_appmanager.adapter;

import androidx.annotation.Nullable;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.tj24.module_appmanager.bean.AppBean;

import java.util.List;

public class RcAppGrideAdapter extends BaseQuickAdapter<AppBean,BaseViewHolder> {

    public RcAppGrideAdapter(int layoutResId, @Nullable List<AppBean> data) {
        super(layoutResId, data);
    }

    @Override
    protected void convert(BaseViewHolder helper, AppBean item) {

    }
}
