package com.tj24.appmanager.login;

import android.app.Activity;
import com.tj24.appmanager.model.BaseAppsManagerModel;

public class LoginModel extends BaseAppsManagerModel {
    public LoginModel(Activity mContext) {
        super(mContext);
    }


}
