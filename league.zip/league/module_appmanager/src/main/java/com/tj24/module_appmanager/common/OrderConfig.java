package com.tj24.module_appmanager.common;

public class OrderConfig {
    public static final String ORDER_LAST_USE = "最近使用";
    public static final String ORDER_OPEN_NUM = "打开次数";
    public static final String ORDER_INSTALL_TIME = "安装时间";
    public static final String ORDER_APP_NAME = "应用名称";
    public static final String ORDER_USE_TIME = "使用时长";
    public static final String ORDER_CUSTOM_PRIORITY = "自定义优先级";

    public static final String SP_ORDER = "sp_order";

    /**
     * 线性排序
     */
    public static final int LAYOUT_LINEAR = 12;
    /**
     * gride排序
     */
    public static final int LAYOUT_Gride = 13;
}
